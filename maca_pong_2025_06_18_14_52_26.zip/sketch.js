// Variáveis da Raquete
let paddleWidth = 100;
let paddleHeight = 20;
let paddleX;
let paddleY;
let paddleSpeed = 7;

// Variáveis da Bolinha
let ballSize = 20;
let ballX;
let ballY;
let ballSpeedX = 5;
let ballSpeedY = 5;

// Variáveis do Jogo
let score = 0;
let gameOver = false;

function setup() {
  createCanvas(600, 400); // Cria um canvas de 600x400 pixels
  resetGame(); // Inicializa o jogo
}

function draw() {
  background(20, 20, 50); // Cor de fundo escura

  if (!gameOver) {
    // Desenha a Raquete
    fill(0, 200, 200); // Cor ciano para a raquete
    rect(paddleX, paddleY, paddleWidth, paddleHeight);

    // Movimento da Raquete
    if (keyIsDown(LEFT_ARROW) || keyIsDown(65)) { // Seta Esquerda ou 'A'
      paddleX -= paddleSpeed;
    }
    if (keyIsDown(RIGHT_ARROW) || keyIsDown(68)) { // Seta Direita ou 'D'
      paddleX += paddleSpeed;
    }

    // Garante que a raquete não saia da tela
    paddleX = constrain(paddleX, 0, width - paddleWidth);

    // Desenha a Bolinha
    fill(255, 100, 100); // Cor vermelha para a bolinha
    ellipse(ballX, ballY, ballSize);

    // Movimento da Bolinha
    ballX += ballSpeedX;
    ballY += ballSpeedY;

    // Colisão da Bolinha com as Bordas (exceto a inferior)
    if (ballX + ballSize / 2 > width || ballX - ballSize / 2 < 0) {
      ballSpeedX *= -1; // Inverte a direção horizontal
    }
    if (ballY - ballSize / 2 < 0) {
      ballSpeedY *= -1; // Inverte a direção vertical
    }

    // Colisão da Bolinha com a Raquete
    if (
      ballY + ballSize / 2 > paddleY &&
      ballX + ballSize / 2 > paddleX &&
      ballX - ballSize / 2 < paddleX + paddleWidth
    ) {
      // Se a bolinha estiver indo para baixo e colidir com a raquete
      if (ballSpeedY > 0) {
        ballSpeedY *= -1; // Inverte a direção vertical
        score++; // Aumenta a pontuação
      }
    }

    // Fim do Jogo
    if (ballY + ballSize / 2 > height) {
      gameOver = true;
    }

    // Exibe a Pontuação
    fill(255); // Cor branca para o texto
    textSize(24);
    textAlign(LEFT, TOP);
    text('Pontuação: ' + score, 10, 10);
  } else {
    // Tela de Game Over
    fill(255);
    textSize(48);
    textAlign(CENTER, CENTER);
    text('GAME OVER!', width / 2, height / 2 - 30);
    textSize(24);
    text('Pontuação Final: ' + score, width / 2, height / 2 + 20);
    text('Pressione ESPAÇO para reiniciar', width / 2, height / 2 + 60);

    // Reinicia o jogo ao pressionar ESPAÇO
    if (keyIsDown(32)) { // Tecla ESPAÇO
      resetGame();
    }
  }
}

// Função para resetar o jogo
function resetGame() {
  paddleX = width / 2 - paddleWidth / 2; // Centraliza a raquete
  paddleY = height - paddleHeight - 10; // Perto da parte inferior

  ballX = width / 2; // Centraliza a bolinha
  ballY = height / 2;
  ballSpeedX = random([-5, 5]); // Começa com velocidade aleatória
  ballSpeedY = 5;

  score = 0;
  gameOver = false;
}

// Evita que a página role quando as setas são pressionadas
function keyPressed() {
  if (keyCode === UP_ARROW || keyCode === DOWN_ARROW || keyCode === LEFT_ARROW || keyCode === RIGHT_ARROW || keyCode === 32) {
    return false;
  }
}